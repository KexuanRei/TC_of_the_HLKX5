import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from edge_copy import EdgeCopier


class CloudFileFlowTests(unittest.TestCase):
    def test_every_round_uses_cloud_replacement_without_clipboard(self):
        with tempfile.TemporaryDirectory() as d:
            copier = EdgeCopier(Path(d))
            config = {'sync': {}, 'source': {}, 'upload': {}}
            copier.mark_prepare()
            with patch('cloud_file_replace.replace_cloud_file', return_value={'message':'ok'}) as upload, patch('full_upload.upload_whole_table') as legacy:
                copier._run_upload_table_a(config)
                copier._run_upload_table_a(config)
            self.assertEqual(upload.call_count,2)
            legacy.assert_not_called()


class DataOnlyClipboardTests(unittest.TestCase):
    def test_clipboard_data_rows_types_text_with_at_hint_and_keeps_numbers_bare(self):
        from local_clipboard import clipboard_data_rows
        clip = clipboard_data_rows([['001', '2000-1'], ['3.5', '']],
                                   [[None, None], ['3.5', None]])
        html_text = clip['html'].decode('utf-8')
        # 非空文本：x:str + mso-number-format:"@"（@ 不转义），WPS 才不会把 “2000-1”
        # 这类形似日期的文本自动转成日期；外观格式（字体/填充/边框/对齐）一律不带。
        self.assertIn('<td x:str="001" style="mso-number-format:&quot;@&quot;">001</td>', html_text)
        self.assertIn('<td x:str="2000-1" style="mso-number-format:&quot;@&quot;">2000-1</td>', html_text)
        # 数值格只带 x:num、不带任何格式；空文本格不带格式提示。
        self.assertIn('<td x:num="3.5">3.5</td>', html_text)
        self.assertIn('<td x:str=""></td>', html_text)
        self.assertNotIn('mso-number-format:&quot;\\@&quot;', html_text)
        self.assertNotIn('font-family', html_text)
        self.assertEqual(clip['text'], '001\t2000-1\r\n3.5\t\r\n')

    def test_clipboard_data_rows_rejects_bad_shapes_and_nul(self):
        from local_clipboard import clipboard_data_rows
        with self.assertRaises(ValueError):
            clipboard_data_rows([['a'], ['b', 'c']])
        with self.assertRaises(ValueError):
            clipboard_data_rows([['a', 'b']], [[None]])
        with self.assertRaises(ValueError):
            clipboard_data_rows([['a\x00']])

    def test_stage_data_rows_sets_local_clipboard(self):
        from local_clipboard import stage_data_rows
        copier = Mock()
        copier._set_local_clipboard = Mock()
        stage_data_rows(copier, [['1']], [[None]])
        copier._set_local_clipboard.assert_called_once()


if __name__ == '__main__':
    unittest.main()
