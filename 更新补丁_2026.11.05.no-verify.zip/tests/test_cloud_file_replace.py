from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from cloud_file_replace import CloudFiles, validate_filename, replace_cloud_file


class GuardTests(unittest.TestCase):
    def test_filename_requires_complete_xlsx_name(self):
        self.assertEqual(validate_filename('D5(1).xlsx'), 'D5(1).xlsx')
        for bad in ('../a.xlsx', 'a.xls', 'C:\\a.xlsx', 'a.xlsx ', '.xlsx'):
            if bad == 'a.xlsx ':
                self.assertEqual(validate_filename(bad), 'a.xlsx')
            else:
                with self.assertRaises(ValueError):
                    validate_filename(bad)


class ReplaceFlowTests(unittest.TestCase):
    def test_replace_uploads_directly_without_any_verification(self):
        # 不再有回读核验/待核验记录：离线转换后直接上传覆盖并报告完成。
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            copier = Mock(root=root)
            copier.should_stop.return_value = False
            config = {'source': {'sheet_name': '临时'},
                      'upload': {'share_url': 'https://www.kdocs.cn/l/abc123',
                                 'cloud_filename': 'A.xlsx'}}
            record = dict(cells=3, formulas=2, formula_errors=1,
                          path=str(root / 'frozen.xlsx'), sha256='h')
            with patch('cloud_file_replace.CloudFiles') as cls, \
                 patch('cloud_file_replace.freeze_workbook', return_value=record):
                result = replace_cloud_file(copier, config)
            ui = cls.return_value
            ui.open.assert_called_once()
            args = ui.upload.call_args[0]
            self.assertEqual(args[1], 'A.xlsx')
            self.assertEqual(Path(args[0]).name, 'A.xlsx')
            self.assertEqual(Path(args[0]).parts[-4:-2], ('DATA', 'UPLOAD'))
            self.assertEqual(result['uploaded'], 3)
            self.assertEqual(result['formulas'], 2)
            self.assertEqual(result['formula_errors'], 1)
            self.assertNotIn('backup', result)
            self.assertIn('上传覆盖完成', result['message'])
            self.assertFalse((root / 'cloud_upload_pending.json').exists())
            # 回读核验相关的步骤与工具已整体移除。
            self.assertFalse(hasattr(CloudFiles, 'verify'))
            self.assertFalse(hasattr(CloudFiles, 'download_shared'))
            self.assertFalse(hasattr(CloudFiles, 'share'))

    def test_stale_pending_journal_is_ignored_and_upload_reruns(self):
        # 旧版遗留的待核验记录不再改变流程：本轮照常下载转换后直接上传。
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'cloud_upload_pending.json').write_text('{}', encoding='utf-8')
            copier = Mock(root=root)
            copier.should_stop.return_value = False
            config = {'source': {'sheet_name': '临时'},
                      'upload': {'share_url': 'https://www.kdocs.cn/l/abc123',
                                 'cloud_filename': 'A.xlsx'}}
            record = dict(cells=1, formulas=0, formula_errors=0,
                          path=str(root / 'frozen.xlsx'), sha256='h')
            with patch('cloud_file_replace.CloudFiles') as cls, \
                 patch('cloud_file_replace.freeze_workbook', return_value=record):
                replace_cloud_file(copier, config)
            cls.return_value.upload.assert_called_once()


class CloudDomTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from playwright.sync_api import sync_playwright
        cls.pw = sync_playwright().start()
        try:
            cls.browser = cls.pw.chromium.launch(channel='msedge', headless=True)
        except Exception as exc:
            cls.pw.stop()
            raise unittest.SkipTest(str(exc))

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()

    def setUp(self):
        self.context = self.browser.new_context(accept_downloads=True)
        self.addCleanup(self.context.close)
        self.page = self.context.new_page()
        self.ui = CloudFiles(self.page)

    def fixture(self, collision='A'):
        self.page.set_content('''
        <div class="item-container" aria-label="A.xlsx" data-key="file_123"><button action-key="action_share">分享</button></div>
        <div id="uploaderBtn"><button onclick="document.querySelector('#upload').hidden=false">导入</button></div>
        <div hidden><button>上传文件</button></div>
        <button id="upload" hidden onclick="document.querySelector('#file').click()">上传文件</button>
        <input id="file" type="file" hidden onchange="document.querySelector('.kdv-dialog').hidden=false">
        <div class="kdv-dialog" hidden><span>覆盖文件</span><p>当前位置已存在「''' + collision + '''」，请确认是否覆盖？</p>
        <button onclick="document.querySelector('.kdv-dialog').hidden=true">取消</button>
        <button onclick="window.keptBoth=true">保留两者</button>
        <button onclick="window.overwritten=true; document.querySelector('.kdv-dialog').hidden=true; document.querySelector('.file-notify').innerText='正在上传 (0/1)';setTimeout(()=>{document.querySelector('.file-notify').innerText='上传完成 已上传1项';},150)">覆盖</button></div>
        <div class="file-notify"></div>''')

    def test_upload_waits_until_finished_before_returning(self):
        self.fixture()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'A.xlsx'
            path.write_bytes(b'fixture')
            self.ui.upload(path, 'A.xlsx')
            self.assertEqual(self.page.locator('.file-notify').inner_text(), '上传完成 已上传1项')
            self.assertTrue(self.page.evaluate('window.overwritten === true'))
            self.assertFalse(self.page.evaluate('window.keptBoth === true'))

    def test_collision_name_is_not_checked_overwrite_is_direct(self):
        # 按需求不做任何校验：覆盖提示中的文件名不一致也直接点击覆盖。
        self.fixture('Different')
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'A.xlsx'
            path.write_bytes(b'fixture')
            self.ui.upload(path, 'A.xlsx')
            self.assertTrue(self.page.evaluate('window.overwritten === true'))

    def test_missing_unique_target_never_uploads(self):
        self.fixture()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'B.xlsx'
            path.write_bytes(b'fixture')
            with self.assertRaisesRegex(ValueError, '未找到唯一'):
                self.ui.upload(path, 'B.xlsx')
            self.assertFalse(self.page.evaluate('window.overwritten === true'))


if __name__ == '__main__':
    unittest.main()
