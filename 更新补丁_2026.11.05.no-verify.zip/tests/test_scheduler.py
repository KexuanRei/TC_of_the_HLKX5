import json
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

from edge_copy import EdgeCopier, TaskBusyError
from scheduler import TaskScheduler


class SchedulerTests(unittest.TestCase):
    def setUp(self):
        self.copier = Mock()
        self.current = dict(busy=False, last_sync=None)
        self.copier.state.side_effect = lambda: self.current.copy()
        self.reports = Mock()
        self.config = {'sync': {'enabled': True, 'wait_seconds': 30}}
        self.scheduler = TaskScheduler(self.copier, self.reports, lambda: self.config)
        self.scheduler.configure(self.config)
        self.now = 100.0
        self.clock = patch('scheduler.time.monotonic', side_effect=lambda: self.now)
        self.clock.start()
        self.addCleanup(self.clock.stop)

    def tick(self):
        self.scheduler._maybe_run(self.config)

    def complete(self, success=True, id='one'):
        self.current.update(busy=False, last_sync=dict(id=id, finished=self.now,
            success=success, completed_at='2026-10-26T10:00:00Z', error='' if success else 'failed'))

    def test_wait_begins_at_actual_finish_not_submission(self):
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.assertIsNone(self.scheduler.state()['tasks']['sync']['last_ok'])
        self.current['busy'] = True
        self.now = 900
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.complete()
        self.tick()
        self.assertIsNotNone(self.scheduler.state()['tasks']['sync']['last_ok'])
        self.now = 929.99
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.now = 930
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 2)
        json.dumps(self.scheduler.state(), allow_nan=False)

    def test_submission_alone_never_means_completion_or_success(self):
        self.tick()
        self.now = 5000
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.assertIsNone(self.scheduler.state()['tasks']['sync']['last_ok'])

    def test_failed_round_waits_30_seconds_and_is_not_success(self):
        self.tick()
        self.now = 120
        self.complete(False)
        self.tick()
        state = self.scheduler.state()['tasks']['sync']
        self.assertEqual(state['last_error'], 'failed')
        self.assertIsNone(state['last_ok'])
        self.now = 149
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.now = 150
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 2)

    def test_configured_interval_controls_wait(self):
        # 其他人的修改只能靠循环扫描发现，等待时间由 sync.wait_seconds 决定。
        self.scheduler.configure({'sync': {'enabled': True, 'wait_seconds': 120}})
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.now = 500
        self.complete()
        self.tick()
        self.now = 619.99
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.now = 620
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 2)

    def test_validation_failure_retries_after_wait(self):
        self.copier.submit_sync.side_effect = ValueError('bad config')
        self.tick()
        self.now = 129
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 1)
        self.now = 130
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 2)

    def test_busy_does_not_consume_interval(self):
        self.copier.submit_sync.side_effect = [TaskBusyError({}), None]
        self.tick()
        self.tick()
        self.assertEqual(self.copier.submit_sync.call_count, 2)

    def test_stopped_loop_cannot_submit_or_disable_new_loop(self):
        event = threading.Event()
        event.set()
        self.scheduler._maybe_run(self.config, event)
        self.copier.submit_sync.assert_not_called()

    def test_disabled_does_not_submit(self):
        self.scheduler.configure({'sync': {'enabled': False}})
        self.tick()
        self.copier.submit_sync.assert_not_called()

    def test_worker_reports_completion_atomically_with_busy_clear(self):
        copier = EdgeCopier('.')
        copier.active_task = dict(id='job', kind='sync')
        copier.status['busy'] = True
        copier._finish_task(success=True)
        state = copier.state()
        self.assertFalse(state['busy'])
        self.assertTrue(state['last_sync']['success'])
        self.assertEqual(state['last_sync']['id'], 'job')
        self.assertEqual(state['last_sync']['finished'], self.now)

class WatchPollTests(unittest.TestCase):
    def _copier(self):
        copier = EdgeCopier('.')
        copier._watch_config = {'sync': {'watch_enabled': True, 'watch_debounce': 1.0}}
        copier._watch_pending = set()
        copier._watch_changed_at = None
        copier._watch_install_at = 100.0
        copier.status['busy'] = False
        page = Mock()
        page.is_closed.return_value = False
        copier.page_c = page
        copier.drain_dirty_rows = Mock()
        copier.submit_sync_rows = Mock()
        return copier

    def test_poll_watch_waits_for_debounce_then_submits(self):
        copier = self._copier()
        copier.drain_dirty_rows.side_effect = [[3, 5], [], []]
        clock = {'now': 100.0}
        with patch('edge_copy.time.monotonic', side_effect=lambda: clock['now']):
            copier._poll_watch()
            copier.submit_sync_rows.assert_not_called()
            clock['now'] = 101.5
            copier._poll_watch()
        copier.submit_sync_rows.assert_called_once_with(copier._watch_config, [3, 5])

    def test_poll_watch_disabled_does_nothing(self):
        copier = self._copier()
        copier._watch_config = {'sync': {'watch_enabled': False, 'watch_debounce': 1.0}}
        copier._poll_watch()
        copier.drain_dirty_rows.assert_not_called()
        copier.submit_sync_rows.assert_not_called()


class FullUploadFlowTests(unittest.TestCase):
    def test_sync_downloads_table_c_then_full_uploads(self):
        # 用临时目录隔离，避免与项目根目录的既有文件互相影响。
        with tempfile.TemporaryDirectory() as d:
            copier = EdgeCopier(d)
            config = {'sync': {'table_b_snapshot': False}}
            with patch.object(copier, '_run_download_table_c', return_value=config) as download, \
                 patch.object(copier, '_run_upload_table_a', return_value={'uploaded': 3, 'message': 'ok'}) as upload:
                result = copier._run_sync(config)
        download.assert_called_once_with(config)
        upload.assert_called_once_with(config)
        self.assertEqual(result['uploaded'], 3)

    def test_cloud_adapter_owns_backup_without_duplicate_download(self):
        with tempfile.TemporaryDirectory() as d:
            copier = EdgeCopier(d)
            config = {'sync': {'table_b_snapshot': True}}
            with patch.object(copier, '_run_download_table_c', return_value=config), \
                 patch.object(copier, '_run_download_table_b') as snapshot, \
                 patch.object(copier, '_run_upload_table_a', return_value={'message': 'ok'}):
                copier._run_sync(config)
        snapshot.assert_not_called()

    def test_snapshot_disabled_skips_table_b_download(self):
        with tempfile.TemporaryDirectory() as d:
            copier = EdgeCopier(d)
            config = {'sync': {'table_b_snapshot': False}}
            with patch.object(copier, '_run_download_table_c', return_value=config), \
                 patch.object(copier, '_run_download_table_b') as snapshot, \
                 patch.object(copier, '_run_upload_table_a', return_value={'message': 'ok'}):
                copier._run_sync(config)
        snapshot.assert_not_called()
