import io
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile, ZIP_DEFLATED

from values_workbook import freeze_workbook, scan_sheet, MAIN


def make_book(path, cells):
    with ZipFile(path, 'w', ZIP_DEFLATED) as z:
        z.writestr('xl/workbook.xml', f'<workbook xmlns="{MAIN}"><sheets><sheet name="临时" sheetId="1"/></sheets></workbook>')
        z.writestr('xl/worksheets/sheet1.xml', f'<worksheet xmlns="{MAIN}"><cols><col min="1" max="3" width="23"/></cols><sheetData><row r="1" ht="30">{cells}</row></sheetData><mergeCells><mergeCell ref="C2:D2"/></mergeCells><conditionalFormatting sqref="A1"><cfRule type="expression"><formula>A1&gt;1</formula></cfRule></conditionalFormatting></worksheet>')
        z.writestr('xl/styles.xml', b'<styles preserve="WPS extensions"/>')
        z.writestr('xl/drawings/image.bin', b'unchanged image')
        z.writestr('xl/calcChain.xml', b'<calcChain/>')
        z.writestr('[Content_Types].xml', '<Types><Override PartName="/xl/calcChain.xml"/><Override PartName="/xl/styles.xml"/></Types>')
        z.writestr('xl/_rels/workbook.xml.rels', '<Relationships><Relationship Id="r1" Type="http://example/calcChain" Target="calcChain.xml"/><Relationship Id="r2" Type="http://example/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')


class FreezeTests(unittest.TestCase):
    def test_preserves_every_byte_except_cell_formulas(self):
        cells = ('<c r="A1" s="4"><f t="shared" si="0">1+2</f><v>3</v></c>'
                 '<c r="B1" t="str"><f t="shared" si="0"/><v>2000-1</v></c>'
                 '<c r="C1" t="str"><f>""</f><v/></c>'
                 '<c r="D1" t="e"><f>#REF!</f><v>#REF!</v></c>'
                 '<c r="E1" s="9"><f t="array" ref="E1:E2">SUM(A1:B1)</f><v>45200</v></c>'
                 '<c r="F1" t="inlineStr"><is><t>001</t></is></c>')
        with tempfile.TemporaryDirectory() as d:
            src, dst = Path(d)/'source.xlsx', Path(d)/'out.xlsx'
            make_book(src, cells)
            original = src.read_bytes()
            result = freeze_workbook(src, dst)
            self.assertEqual(result['formulas'], 5)
            self.assertEqual(result['formula_errors'], 1)
            self.assertEqual(src.read_bytes(), original)
            with ZipFile(src) as a, ZipFile(dst) as b:
                for name in ('xl/styles.xml', 'xl/drawings/image.bin', 'xl/workbook.xml'):
                    self.assertEqual(a.read(name), b.read(name))
                content = b.read('xl/worksheets/sheet1.xml')
                expected = a.read('xl/worksheets/sheet1.xml')
                for formula in (b'<f t="shared" si="0">1+2</f>', b'<f t="shared" si="0"/>', b'<f>""</f>', b'<f>#REF!</f>', b'<f t="array" ref="E1:E2">SUM(A1:B1)</f>'):
                    expected = expected.replace(formula, b'')
                self.assertEqual(content, expected)
                self.assertNotIn('xl/calcChain.xml', b.namelist())
                self.assertNotIn(b'calcChain', b.read('[Content_Types].xml'))
                self.assertNotIn(b'calcChain', b.read('xl/_rels/workbook.xml.rels'))
            with ZipFile(src) as a, ZipFile(dst) as b:
                self.assertEqual(set(a.namelist()) - {'xl/calcChain.xml'}, set(b.namelist()))

    def test_missing_cache_never_replaces_existing_output(self):
        for cache in ('', '<v/>'):
            with self.subTest(cache=cache), tempfile.TemporaryDirectory() as d:
                src, dst = Path(d)/'s.xlsx', Path(d)/'out.xlsx'
                make_book(src, '<c r="B9"><f>1+2</f>'+cache+'</c>')
                dst.write_bytes(b'previous output')
                with self.assertRaisesRegex(ValueError, 'B9.*缺少计算结果'):
                    freeze_workbook(src, dst)
                self.assertEqual(dst.read_bytes(), b'previous output')
                self.assertEqual(len(list(Path(d).glob('.values-*'))), 0)

    def test_prefixed_xml_and_self_closing_formula_at_chunk_boundary(self):
        xml = f'<x:worksheet xmlns:x="{MAIN}"><x:sheetData><x:row><x:c r="A1"><x:f t="shared"/><x:v>12</x:v></x:c></x:row></x:sheetData></x:worksheet>'.encode()
        scan = scan_sheet(io.BytesIO(xml), 'sheet')
        start, end = scan.spans[0]
        self.assertEqual(xml[start:end], b'<x:f t="shared"/>')

    def test_in_place_write_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d)/'a.xlsx'
            with self.assertRaisesRegex(ValueError,'不能覆盖'):
                freeze_workbook(src,src)


if __name__ == '__main__':
    unittest.main()
